SG Technical Android App Project

Open this folder in Android Studio, wait for Gradle sync, then Build > Build APK(s).
The app wraps the existing professional SG Technical UI locally; Supabase remains the live backend.
No HTTP File Server or Chrome is required after APK installation.
