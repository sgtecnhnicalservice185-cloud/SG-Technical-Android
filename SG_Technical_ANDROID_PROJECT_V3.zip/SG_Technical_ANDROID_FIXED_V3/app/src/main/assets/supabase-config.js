const SUPABASE_URL = 'https://lvflqlshmmkvebtkphwq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_4XeteAHij6cIBShcaXhpAw_SS7iS2cP';
